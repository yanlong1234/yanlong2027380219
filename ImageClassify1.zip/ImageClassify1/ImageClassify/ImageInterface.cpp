#include "pch.h"
#include "ImageInterface.h"

CImageInterface::CImageInterface()
{

}

CImageInterface::~CImageInterface()
{

}

void CImageInterface::ImageClassify(string strPath)
{

}
