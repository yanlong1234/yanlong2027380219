#pragma once
class CIpcClient
{
	CIpcClient();
	~CIpcClient();
	void SendPackage();
	void Start();
	void Stop();
};

