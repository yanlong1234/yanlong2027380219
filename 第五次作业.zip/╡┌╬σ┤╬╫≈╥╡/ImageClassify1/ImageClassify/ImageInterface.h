#pragma once
#include <string>

using namespace std;
class CImageInterface
{
	CImageInterface();
	~CImageInterface();
	void ImageClassify(string strPath);
};

