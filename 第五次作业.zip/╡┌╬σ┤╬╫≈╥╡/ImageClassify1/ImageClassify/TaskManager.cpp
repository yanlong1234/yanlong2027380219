#include "pch.h"
#include "TaskManager.h"

CTaskManager::CTaskManager()
{

}

CTaskManager::~CTaskManager()
{

}

void CTaskManager::AddTask()
{

}
