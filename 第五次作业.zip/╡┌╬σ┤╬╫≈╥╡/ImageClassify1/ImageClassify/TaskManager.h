#pragma once
class CTaskManager
{
	CTaskManager();
	~CTaskManager();

	void AddTask();
};

