#include "pch.h"
#include "IpcClient.h"

CIpcClient::CIpcClient()
{

}

CIpcClient::~CIpcClient()
{

}

void CIpcClient::SendPackage()
{

}

void CIpcClient::Start()
{

}

void CIpcClient::Stop()
{

}
